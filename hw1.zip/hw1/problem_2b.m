B = [1, 1/2, 0]; %# Coefficients for x 
A = [1, -1.8*cos(pi/16), 0.81]; %# Coefficients for y 

n=-10:100;
x=zeros(1,111);
x(0+11)=1;

y = filter(B, A, x);
 
stem(n,y)
xlabel('time')
ylabel('amplitude')
title('filter')
xlim([-10 100])