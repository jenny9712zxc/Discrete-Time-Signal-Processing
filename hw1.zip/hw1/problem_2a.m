global result;
n=-10:100;
result=zeros(1,111);%-10~100
 
 for i=-10:100
     result(i+11)= func(i);
 end
 
stem(n,result)
xlabel('time')
ylabel('amplitude')
title('recursive')
xlim([-10 100])
 
 function y = func(n)
 global result;
    if n<0
        y = 0;
    elseif n==0
        y = input(0);
    else
        y = 1.8*cos(pi/16)*result(n-1+11) - 0.81*result(n-2+11) + input(n) + 1/2*input(n-1);
        %y = 1.8*cos(pi/16)*func(n-1) - 0.81*func(n-2) + input(n) + 1/2*input(n-1);
    end
end   
     
function ans = input(t)
    if t==0
        ans=1;
    else
        ans=0;
    end
end