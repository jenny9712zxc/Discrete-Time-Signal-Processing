n=0:20;
x=(0.9).^n;
stem(n,x)
xlabel('time')
ylabel('amplitude')
title('exponential signal')
xlim([0 20])
