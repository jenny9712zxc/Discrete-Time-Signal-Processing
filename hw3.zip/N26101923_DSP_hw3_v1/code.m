clear;
clc;

[audioIn,fs] = audioread('input.wav');

%Increase the pitch
nsemitones = 6;
audioOutIncrease = shiftPitch(audioIn,nsemitones, 0);


%Decrease the pitch
nsemitones = -6;
audioOutDecrease = shiftPitch(audioIn,nsemitones, 0);


subplot(3,1,1);
spectrogram(audioIn,'yaxis')
title('original') 

subplot(3,1,2);
spectrogram(audioOutIncrease,'yaxis')
title('6 semitones higher') 

subplot(3,1,3);
spectrogram(audioOutDecrease,'yaxis')
title('6 semitones lower ') 