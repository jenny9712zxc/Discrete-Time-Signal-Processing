%%
clc;
clear;

[clean_data, clean_rate] = audioread('clean.wav');
[noisy_data, noisy_rate] = audioread('noisy.wav');

subplot(2,1,1);
spectrogram(clean_data, clean_rate,'yaxis');
title('clean audio');

subplot(2,1,2);
spectrogram(noisy_data, noisy_rate,'yaxis');
title('noisy audio');
%%
clc;
clear;
[clean_data, clean_rate] = audioread('clean.wav');
[noisy_data, noisy_rate] = audioread('noisy.wav');

sample_rate = clean_rate
Fn = sample_rate/2;                                       % Nyquist Frequency (Hz)
Wp = 1000/Fn;                                             % Passband Frequency (Normalised)
Ws = 1010/Fn;                                             % Stopband Frequency (Normalised)
Rp =   1;                                                 % Passband Ripple (dB)
Rs = 150;                                                 % Stopband Ripple (dB)
[n,Ws] = cheb2ord(Wp,Ws,Rp,Rs);                           % Filter Order
[z,p,k] = cheby2(n,Rs,Ws,'low');                          % Filter Design
[soslp,glp] = zp2sos(z,p,k);                              % Convert To Second-Order-Section For Stability

filtered_clean_sound = filtfilt(soslp, glp, clean_data);
filtered_noisy_sound = filtfilt(soslp, glp, noisy_data);

subplot(2,1,1);
spectrogram(filtered_clean_sound, sample_rate,'yaxis');
title('clean audio');

subplot(2,1,2);
spectrogram(filtered_noisy_sound, sample_rate,'yaxis');
title('noisy audio');
