input='singing16k16bit-clean.wav';
[y,oldrate] = audioread(input);

newrate=12000;

L=lcm(oldrate,newrate);
zup=interp(y,L/oldrate);
zdown=downsample(zup,L/newrate);
audiowrite('output.wav',zdown,newrate);

subplot(2,1,1);
plot((0:length(y)-1)/oldrate,y);
title('16kb');
subplot(2,1,2);
plot((0:length(zdown)-1)/newrate,zdown);
title('12kb');

